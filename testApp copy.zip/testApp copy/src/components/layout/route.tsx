import { Route, BrowserRouter as Router, Routes } from "react-router-dom";
import { EmployeeList } from "../screens/employees";
import { JobList } from "../screens/joblist";
import { ServiceItemsList } from "../screens/service-item-list";
import { MainMenu } from "./main-menu";

export function RouterComponent() {
  return (
    <Router>
      <Routes>
        <Route path="/employees" element={<EmployeeList />} />
        <Route path="/jobs" element={<JobList />} />
        <Route path="/serviceItems" element={<ServiceItemsList />} />
        <Route path="*" element={<MainMenu />} />
      </Routes>
    </Router>
  );
}
