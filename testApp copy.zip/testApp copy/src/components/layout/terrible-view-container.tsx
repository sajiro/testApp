export function TerribleViewContainer({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div
      style={{
        fontFamily: "monospace",
        padding: "2em",
        overflow: "scroll",
        whiteSpace: "pre",
        width: "80vh",
        backgroundColor: "#eee",
      }}
    >
      {children}
    </div>
  );
}
