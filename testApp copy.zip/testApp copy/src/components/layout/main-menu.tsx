import { Link } from "react-router-dom";
import { useAuthentication } from "../../App";

export function MainMenu() {
  const authCtx = useAuthentication();
  console.log("authCtx:", authCtx);
  return (
    <div>
      <p>Logged into account: {authCtx.authentication.companyName}</p>
      <p>Main Menu</p>
      <ul style={{ listStyle: "none", paddingInlineStart: 0 }}>
        <li>
          <Link to="/employees">Employees</Link>
        </li>
        <li>
          <Link to="/jobs">Jobs</Link>
        </li>
        <li>
          <Link to="/serviceItems">Service Items</Link>
        </li>
        <li>
          <button onClick={() => authCtx.logout()}>Logout</button>
        </li>
      </ul>
    </div>
  );
}
