import { Link } from "react-router-dom";
import { useVeriClockApi } from "../../hooks/useVeriClockApi";
import { TerribleViewContainer } from "../layout/terrible-view-container";
import { useQuery } from "react-query";
import { convertLineBreaksToHtml } from "../../helper";
import { useState } from "react";
import { ITEMS_PER_PAGE } from "../../config";
import styled from "styled-components";

const Title = styled.h1`
  font-size: 1.5em;
  text-align: center;
  color: #bf4f74;
`;

export function JobList() {
  const api = useVeriClockApi();
  const {
    data: jobs,
    isLoading,
    isError,
  } = useQuery(["jobList"], () => api.fetchJobs());
  const [pageNumber, setPageNumber] = useState(1);

  const visibleJobs = jobs ? jobs.slice(0, pageNumber * ITEMS_PER_PAGE) : [];

  console.log(jobs?.length);

  const handleShowMore = () => {
    setPageNumber((prevPageNumber) => prevPageNumber + 1);
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (isError) {
    return <div>Error fetching Jobs</div>;
  }

  /* jobs?.forEach((job) => {
    job.description = `sadasd sdasdasd asd 
                 asd 111111
    222222
    asd`;
  }); */

  return (
    <div>
      <h2>Jobs</h2>
      <Title>Jobs</Title>
      <i style={{ color: "red" }}>Job List Here:</i>
      <Link to="/">Back to Main Menu</Link>

      <TerribleViewContainer>
        {jobs && JSON.stringify(jobs[0])}
      </TerribleViewContainer>
      {visibleJobs?.map((job, idx) => (
        <div key={job.guid}>
          <div
            dangerouslySetInnerHTML={{
              __html: convertLineBreaksToHtml(job.description),
            }}
          ></div>
          <div>
            {idx} {job.name}
          </div>
        </div>
      ))}

      {visibleJobs.length < (jobs?.length ?? 0) && (
        <button onClick={handleShowMore} disabled={isLoading}>
          {isLoading ? "Loading more..." : "Show More"}
        </button>
      )}
    </div>
  );
}
