import { useCallback, useContext, useState } from "react";
import {
  AuthenticationResponse,
  LoginFormProps,
  TestConfig,
} from "../../models/models";
import { defaults } from "../../config";
import { authenticate } from "../../service/api";
import { AuthenticationContext, isTestApiError } from "../../App";
import styled from "styled-components";

const Title = styled.h1`
  font-size: 1.5em;
  text-align: center;
  color: #bf4f74;
`;

export function Login({
  config,
  onLogin,
}: /*  loggingIn, */
/*  setUsername,
  setPassword, */
LoginFormProps) {
  const authCtx = useContext(AuthenticationContext);
  console.log(config, "++++GEGEGE", authCtx);
  const [configState, setConfigState] = useState<TestConfig>(defaults);
  const [usernameState, setUsernameState] = useState(
    "frontend1+ErwinRosario@vericlock.com"
  );
  const [passwordState, setPasswordState] = useState("qwerqwer1234");
  const [loggingInState, setLoggingInState] = useState(false);
  const [authentication, setAuthentication] =
    useState<AuthenticationResponse | null>(null);

  /*   const [configa, setConfiga] = useState<TestConfig>(defaults); */
  /*   
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loggingIn, setLoggingIn] = useState(false);
  const [authentication, setAuthentication] =
    useState<AuthenticationResponse | null>(null); */

  const tryLogin = useCallback(
    async () => {
      setLoggingInState(true);

      try {
        const authResponse = await authenticate(
          config,
          usernameState,
          passwordState
        );

        console.log("authResponse------", authResponse);
        setAuthentication(authResponse);
        onLogin(authResponse);
      } catch (err) {
        if (isTestApiError(err)) {
          if (err.response.status === 401) {
            alert(`Invalid username or password. Please try again.`);
            return;
          } else if (err.response.status === 403) {
            alert(
              `Your account is not authorized to use this application. Please contact support.`
            );
            return;
          } else {
            alert(
              `Server response code: ${err.response.status} - ${JSON.stringify(
                err.body
              )} There was a problem logging in. Please reload the page and try again. Contact support if the problem persists.`
            );
            return;
          }
        }
        console.error(err);
        alert(
          `There was an unknown problem logging in. Please reload the page and try again. Contact support if the problem persists.`
        );
      } finally {
        setLoggingInState(false);
      }
    },
    [
      /* username, password, config */
    ]
  );

  return (
    <div className="App" style={{ backgroundColor: "yellow" }}>
      LOGIN NEW COMPONENT
      {!!loggingInState ? (
        <div>logging In</div>
      ) : (
        <>
          <p>
            <input
              type="text"
              onChange={(e) =>
                setConfigState({ ...config, baseUrl: e.target.value })
              }
              value={config.baseUrl}
              placeholder="API Base URL"
            />
            <br />
            <input
              type="text"
              onChange={(e) =>
                setConfigState({
                  ...config,
                  VERICLOCK_API_PUBLIC_KEY:
                    "87bce028-b39f-4a7a-9139-944c324c35c6",
                })
              }
              value={config.VERICLOCK_API_PUBLIC_KEY}
              placeholder="API Public Key"
            />
            <br />
            <input
              type="text"
              onChange={(e) =>
                setConfigState({
                  ...config,
                  VERICLOCK_DOMAIN: "erwinrosariocorp",
                })
              }
              value={config.VERICLOCK_DOMAIN}
              placeholder="VeriClock Domain"
            />
            <br />
          </p>
          <p>
            <input
              type="text"
              onChange={(e) =>
                setUsernameState("frontend1+ErwinRosario@vericlock.com")
              }
              value={usernameState}
              placeholder="username"
            />
          </p>
          <p>
            <input
              type="password"
              onChange={(e) => setPasswordState("qwerqwer1234")}
              value={passwordState}
              placeholder="password"
            />
          </p>
          <p>
            <button onClick={tryLogin}>Login</button>
          </p>
        </>
      )}
    </div>
  );
}
