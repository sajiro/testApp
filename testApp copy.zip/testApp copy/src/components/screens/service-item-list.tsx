import { Link } from "react-router-dom";
import { useVeriClockApi } from "../../hooks/useVeriClockApi";
import { TerribleViewContainer } from "../layout/terrible-view-container";
import { ServiceItem } from "../../models/models";
import { useState } from "react";
import { useQuery } from "react-query";

export function ServiceItemsList() {
  const api = useVeriClockApi();

  const {
    data: serviceItemList,
    isLoading,
    isError,
  } = useQuery("serviceItems", () => api.fetchServiceItems());

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (isError) {
    return <div>Error fetching serviceItems</div>;
  }

  return (
    <div>
      <h2>Service Items</h2>
      <i style={{ color: "red" }}>Servce Item List Here:</i>
      <TerribleViewContainer>
        {JSON.stringify(serviceItemList)}
      </TerribleViewContainer>

      <Link to="/">Back to Main Menu</Link>
      {serviceItemList &&
        serviceItemList?.map((item) => (
          <div key={item.guid}>{`${item.name}`}</div>
        ))}
    </div>
  );
}
