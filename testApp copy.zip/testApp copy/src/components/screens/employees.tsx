import { Link } from "react-router-dom";
import { TerribleViewContainer } from "../layout/terrible-view-container";
import { useEffect, useState } from "react";
import { useVeriClockApi } from "../../hooks/useVeriClockApi";
import { useQuery } from "react-query";

export function EmployeeList() {
  const api = useVeriClockApi();

  const {
    data: employees,
    isLoading,
    isError,
  } = useQuery("employees", () => api.fetchEmployees());

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (isError) {
    return <div>Error fetching employees</div>;
  }

  return (
    <div>
      <h2>Employees</h2>
      <i style={{ color: "red" }}>Employee List Here:</i>
      <Link to="/">Back to Main Menu</Link>
      <TerribleViewContainer>
        {/* {JSON.stringify(employeeList)} */}ssss
      </TerribleViewContainer>
      {employees &&
        employees?.map((employee) => (
          <div
            key={employee.guid}
          >{`${employee.firstName} ${employee.lastName}`}</div>
        ))}
      {/*  <button onClick={loadEmployees}>Load Employees</button>
      <br />
      <br /> */}
    </div>
  );
}
